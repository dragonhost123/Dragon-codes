# Dragon Panel

Simple custom game server panel with node and location management, user login, and Wings daemon integration.

---

## Features

- Admin user creation  
- Node & location management  
- Basic JWT authentication  
- React frontend with nebula theme  
- Auto-install Wings daemon with config generation

---

## Requirements

- Node.js v18+  
- npm  
- SQLite3  
- Bash shell (Linux environment recommended)  
- Docker (optional, recommended for Wings)

---

## Setup Instructions

### Backend

1. Navigate to `backend` folder:

    ```bash
    cd backend
    ```

2. Install dependencies:

    ```bash
    npm install
    ```

3. Create admin user (replace info with your own):

    ```bash
    node scripts/createAdmin.js admin@example.com admin adminFirst adminLast yourpassword
    ```

4. Start backend server:

    ```bash
    npm start
    ```

Server runs on `http://localhost:3001`

---

### Frontend

1. Navigate to `frontend` folder:

    ```bash
    cd frontend
    ```

2. Install dependencies:

    ```bash
    npm install
    ```

3. Start frontend app:

    ```bash
    npm start
    ```

Frontend runs on `http://localhost:3000`

---

### Wings Daemon

1. Run the Wings install script:

    ```bash
    chmod +x install_wings.sh
    sudo ./install_wings.sh
    ```

2. Wings runs on port `8080`

---

### Access Panel

Open browser at:

```
http://localhost:3000
```

Login with your admin credentials.

---

## Notes

- Replace `your-token-id` and `your-token` in `/etc/pterodactyl/config.yml` with actual values once available  
- This is a basic working panel; expand features as needed  
- No advanced error handling implemented — keep it simple and clear

---

## License

MIT License

---

## Author

Your Name